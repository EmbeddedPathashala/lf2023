#! /bin/xyz

echo "one"
