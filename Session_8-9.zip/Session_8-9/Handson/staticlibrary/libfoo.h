int add(int a, int b);
int subtract(int a, int b);
