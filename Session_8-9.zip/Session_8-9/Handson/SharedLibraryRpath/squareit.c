#include "squareit.h"

int square(int num) {
    return num * num;
}

