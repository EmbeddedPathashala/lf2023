int square(int num);
