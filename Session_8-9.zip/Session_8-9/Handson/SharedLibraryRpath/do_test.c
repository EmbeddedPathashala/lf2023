#include <stdio.h>
#include "squareit.h"

int main() {
    int n = 3;
    printf("square(%d) = %d\n", n, square(3));
}
