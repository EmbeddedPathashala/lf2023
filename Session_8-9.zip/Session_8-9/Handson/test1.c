        struct a
        {
                long a;
                long b;
                long c;
                long d;
                long e;
                long f;
                long h;
        };



long func1(struct a test)
{
	return 10;
}


int main()
{
	struct a b;
	b.a=1;
	b.b=2;
	b.h=7;
	func1(b);
	return 0;
}
