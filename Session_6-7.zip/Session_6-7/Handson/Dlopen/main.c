#define _GNU_SOURCE
#include <link.h>
#include <stdlib.h>
#include <stdio.h>
#include <dlfcn.h>


static int header_handler(struct dl_phdr_info* info, size_t size, void* data)
{
    printf("name=%s (%d segments) address=%p\n",
            info->dlpi_name, info->dlpi_phnum, (void*)info->dlpi_addr);
    for (int j = 0; j < info->dlpi_phnum; j++) {
         printf("\t\t header %2d: address=%10p\n", j,
             (void*) (info->dlpi_addr + info->dlpi_phdr[j].p_vaddr));
         printf("\t\t\t type=%u, flags=0x%X\n",
                 info->dlpi_phdr[j].p_type, info->dlpi_phdr[j].p_flags);
    }
    printf("\n");
    return 0;
}


int (*func)(int a,int b);

int main(int argc, const char* argv[])
{
    void *lib;
    dl_iterate_phdr(header_handler, NULL);

    //lib=dlopen("./libmylib.so",RTLD_LAZY);
    lib=dlopen("./libmylib.so",RTLD_NOW);
    printf("dlopen done\n");
    func=dlsym(lib,"ml_func");
    printf("dlsym mapped\n");
    int t = func(argc, argc);
    printf("Func executed\n");
     printf("t=%d\n",t);    
    return t;
}
