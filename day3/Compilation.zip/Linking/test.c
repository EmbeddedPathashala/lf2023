#include <stdio.h>

int main()
{
	myprintf("Hello World\n");
	return 0;
}
