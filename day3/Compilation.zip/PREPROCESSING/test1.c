#define A (20)
int main()
{
	return (A);
}
