#include <stdio.h>

int main()
{
	//printf("Hello World\n");
	sleep(10);
	return 0;
}
