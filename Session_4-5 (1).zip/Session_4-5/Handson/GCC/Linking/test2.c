#include <stdio.h>

int myprintf(char* ch)
{
	printf("%s",ch);
	return 0;
}
