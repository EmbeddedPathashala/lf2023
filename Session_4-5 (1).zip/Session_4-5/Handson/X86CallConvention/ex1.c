#include <stdio.h>
int  array[1024*1024];
int x=10;
int main()
{
	printf("Hello World =%d\n",x);
	return 1;
}
